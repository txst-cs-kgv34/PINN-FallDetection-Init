# S63 Stage 3 gain sweep — chunk 1 export

This package contains the trained Stage 3 model and matched synthetic CoM trajectories produced by chunk 1 of the S63 A11 fixed-gain sweep.

## Controller configuration

| Parameter | Value |
|---|---:|
| Kp_theta | 145.109024 |
| Kd_theta | 15.048624 |
| Kp_x | 14.932888 |
| Kd_x | 15.048451 |
| Fixed Pi | 3.628571 deg |
| Fixed tau | 0.23 s |
| Stage 3 epochs | 5,000 |
| Batch size | 4,096 |

Chunk 1 is the **S63 model-predicted control-gain endpoint** obtained from the completed inverse/control-identification pipeline.

## Reconstruction results

| Metric | Chunk 1: S63 predicted | Chunk 6: best combined |
|---|---:|---:|
| Normalized MSE | 0.127258 | **0.103263** |
| Theta MSE | **30.6773 deg^2** | 36.7899 deg^2 |
| Theta RMSE | **5.5387 deg** | 6.0655 deg |
| Forward-x MSE | 48.8592 cm^2 | **27.7494 cm^2** |
| Forward-x RMSE | 6.9899 cm | **5.2678 cm** |
| Theta pooled W1 | 0.5066 deg | **0.4921 deg** |
| Forward-x pooled W1 | **0.3710 cm** | 0.6632 cm |

Chunk 1 and chunk 6 show a clear theta-versus-x trade-off:

- chunk 1 has 16.61% lower theta MSE than chunk 6;
- chunk 1 has 76.07% higher x MSE than chunk 6;
- chunk 1's combined normalized MSE is 23.24% above chunk 6.

Therefore, the two settings should not be described as having only a minor overall error difference. Chunk 1 is better for paired theta reconstruction and early x-distribution similarity, while chunk 6 is much better for full-trajectory x reconstruction and combined MSE.

The combined normalized loss uses output scales of 25 deg and 25 cm:

- normalized theta contribution: 30.6773 / 25^2 = 0.049084, or 38.6% of the total;
- normalized x contribution: 48.8592 / 25^2 = 0.078175, or 61.4% of the total.

This can be described as a **moderate error trade-off**, with the normalized loss weighted more toward x error. A cautious statement is that the model-predicted gains retain meaningful performance in both outputs, but they are less evenly balanced than chunk 6 and are not the best combined-reconstruction gains.

## Package contents

- `trained_model/stage3_best.weights.h5`: best restored Stage 3 model weights.
- `trained_model/final_stage3.weights.h5`: final exported weights; byte-identical to the best weights.
- `synthetic_data/synthetic_only/`: five synthetic-only CSVs with `time_s, theta_deg, x_cm`.
- `synthetic_data/paired_real_vs_synthetic/`: original matched CSVs used to calculate MSE.
- `metrics/result.json`: pooled gains and metrics.
- `metrics/mse_by_trial.csv`: per-trial and pooled trajectory errors.
- `metrics/stage3_loss_history.csv`: all 5,000 loss values.
- `metrics/time_resolved_means_and_distances.csv`: early mean and W1 comparisons.
- `figures/`: real/synthetic trajectory and distribution-comparison plots.
- `experiment_code/run_gain_sweep.py`: exact sweep runner for provenance.
- `SHA256SUMS.txt`: integrity hashes for every packaged file.

The synthetic files are five matched forward simulations, one for each measured S63 A11 trial. They are not the earlier collection of 100 random-initial-angle trajectories.

The inherited `SubjectB_` filename prefix is only the unchanged pole loader's naming contract; the files contain Subject 63 data.

## Model-loading note

These HDF5 files contain Keras weights, not a standalone serialized architecture. Load them into the original `ConditionalPolePINN` architecture from `source/pinn_pole_synthetic_data_generation.py` in the S63 project. The model must be built with its five-input signature before calling `load_weights`.
