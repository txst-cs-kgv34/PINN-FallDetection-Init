# S63 Stage 3 gain sweep — chunk 6 export

This package contains the trained Stage 3 model and matched synthetic CoM trajectories produced by chunk 6 of the S63 A11 fixed-gain sweep.

## Controller configuration

| Parameter | Value |
|---|---:|
| Kp_theta | 197.826233 |
| Kd_theta | 23.354944 |
| Kp_x | 13.859061 |
| Kd_x | 23.354867 |
| Fixed Pi | 3.628571 deg |
| Fixed tau | 0.23 s |
| Stage 3 epochs | 5,000 |
| Batch size | 4,096 |

Chunk 6 is the 55.56% interpolation point between the S63-identified gains and the Subject B paper gains. It is the lowest pooled normalized-MSE setting among the 11 tested chunks.

## Reconstruction results

| Metric | Chunk 6 | Chunk 11 comparison |
|---|---:|---:|
| Normalized MSE | **0.103263** | 0.103816 |
| Theta MSE | **36.7899 deg^2** | 37.0505 deg^2 |
| Theta RMSE | **6.0655 deg** | 6.0869 deg |
| Forward-x MSE | **27.7494 cm^2** | 27.8347 cm^2 |
| Forward-x RMSE | **5.2678 cm** | 5.2759 cm |
| Theta pooled W1 | **0.4921 deg** | 0.4981 deg |
| Forward-x pooled W1 | 0.6632 cm | **0.5135 cm** |

Chunk 6 and chunk 11 are close: chunk 11 is only 0.54% higher in normalized MSE. Their theta MSE differs by 0.71%, and their x MSE differs by 0.31%.

The combined normalized loss uses output scales of 25 deg and 25 cm:

- normalized theta contribution: 36.7899 / 25^2 = 0.058864, or 57.0% of the total;
- normalized x contribution: 27.7494 / 25^2 = 0.044399, or 43.0% of the total.

This supports describing chunk 6 as balanced in the limited metric sense: neither theta nor x accounts for nearly all of the normalized reconstruction loss. It does not prove physiological balance or uniquely identify a human controller.

## Package contents

- `trained_model/stage3_best.weights.h5`: best restored Stage 3 model weights.
- `trained_model/final_stage3.weights.h5`: final exported weights; byte-identical to the best weights.
- `synthetic_data/synthetic_only/`: five synthetic-only CSVs with `time_s, theta_deg, x_cm`.
- `synthetic_data/paired_real_vs_synthetic/`: original matched CSVs used to calculate MSE.
- `metrics/result.json`: pooled gains and metrics.
- `metrics/mse_by_trial.csv`: per-trial and pooled trajectory errors.
- `metrics/stage3_loss_history.csv`: all 5,000 loss values.
- `metrics/time_resolved_means_and_distances.csv`: early mean and W1 comparisons.
- `figures/`: real/synthetic trajectory and distribution-comparison plots.
- `experiment_code/run_gain_sweep.py`: exact sweep runner for provenance.
- `SHA256SUMS.txt`: integrity hashes for every packaged file.

The synthetic files are five matched forward simulations, one for each measured S63 A11 trial. They are not the earlier collection of 100 random-initial-angle trajectories.

The inherited `SubjectB_` filename prefix is only the unchanged pole loader's naming contract; the files contain Subject 63 data.

## Model-loading note

These HDF5 files contain Keras weights, not a standalone serialized architecture. Load them into the original `ConditionalPolePINN` architecture from `source/pinn_pole_synthetic_data_generation.py` in the S63 project. The model must be built with its five-input signature before calling `load_weights`.
