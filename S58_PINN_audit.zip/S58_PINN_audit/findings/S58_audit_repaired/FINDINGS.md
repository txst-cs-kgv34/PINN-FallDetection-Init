# S58 audit findings

Clips passing numeric input checks: 24; empty: 0; missing expected: 1; invalid: 0; analyzed frames: 4281.

Review-flagged destination frames: 464. Duplicate rows within clips: 1797.

These are data-quality screening results, not validated fall labels or anatomical CoM. The audit does not repair inputs itself; when a derived repaired-data directory is supplied, consult its repair manifest and frame mask. Invalid trials remain in raw/ and manifest.json but are withheld from calculations.

| Trial | Status | Frames | Span (s) | Review frames | Duplicate rows | Scale range (%) |
|---|---|---:|---:|---:|---:|---:|
| S58A10T01 | numeric | 134 | 4.433333333333334 | 4 | 101 | 28.303368453615185 |
| S58A10T02 | numeric | 129 | 4.266666666666667 | 5 | 102 | 77.62693769135518 |
| S58A10T03 | numeric | 200 | 6.633333333333334 | 9 | 117 | 28.457359717121022 |
| S58A10T04 | numeric | 223 | 7.4 | 10 | 169 | 40.32348246828934 |
| S58A11T01 | numeric | 159 | 5.266666666666667 | 7 | 112 | 21.02451318006484 |
| S58A11T02 | numeric | 210 | 6.966666666666667 | 3 | 121 | 6.943211671721805 |
| S58A11T03 | numeric | 161 | 5.333333333333333 | 5 | 107 | 53.63255684748835 |
| S58A11T04 | numeric | 190 | 6.3 | 8 | 116 | 97.3288364039289 |
| S58A11T05 | numeric | 149 | 4.933333333333334 | 2 | 112 | 16.920120223938273 |
| S58A12T01 | numeric | 134 | 4.433333333333334 | 6 | 92 | 68.27389078886293 |
| S58A12T02 | numeric | 171 | 5.666666666666667 | 8 | 98 | 29.207692214777015 |
| S58A12T03 | numeric | 185 | 6.133333333333334 | 19 | 3 | 72.10237675381428 |
| S58A12T04 | numeric | 228 | 7.566666666666666 | 76 | 3 | 96.42264654559625 |
| S58A12T05 | numeric | 166 | 5.5 | 32 | 0 | 47.81532203304535 |
| S58A13T01 | numeric | 154 | 5.1 | 36 | 1 | 139.73102169488644 |
| S58A13T02 | numeric | 221 | 7.333333333333333 | 46 | 8 | 107.74307743495103 |
| S58A13T03 | numeric | 161 | 5.333333333333333 | 86 | 2 | 348.2373901414331 |
| S58A13T04 | numeric | 137 | 4.533333333333333 | 6 | 119 | 58.50259729359073 |
| S58A13T05 | numeric | 241 | 8.0 | 40 | 6 | 54.767425359780034 |
| S58A14T01 | numeric | 182 | 6.033333333333333 | 11 | 57 | 41.24006920492895 |
| S58A14T02 | numeric | 185 | 6.133333333333334 | 10 | 106 | 7.899484548999047 |
| S58A14T03 | numeric | 179 | 5.933333333333334 | 5 | 115 | 11.186765049850965 |
| S58A14T04 | numeric | 213 | 7.066666666666666 | 6 | 107 | 17.814827647950814 |
| S58A14T05 | numeric | 169 | 5.6 | 24 | 23 | 62.108803024234625 |
| S58A10T05 | missing | 0 | — | — | — | — |

## Temporal audit

| Trial | Distinct poses | Repeated transitions (%) | Longest constant span (s) |
|---|---:|---:|---:|
| S58A10T01 | 33 | 75.94 | 3.200 |
| S58A10T02 | 27 | 79.69 | 3.400 |
| S58A10T03 | 83 | 58.79 | 3.600 |
| S58A10T04 | 54 | 76.13 | 5.400 |
| S58A11T01 | 47 | 70.89 | 3.600 |
| S58A11T02 | 89 | 57.89 | 4.033 |
| S58A11T03 | 54 | 66.88 | 3.533 |
| S58A11T04 | 74 | 61.38 | 3.533 |
| S58A11T05 | 37 | 75.68 | 3.667 |
| S58A12T01 | 42 | 69.17 | 3.067 |
| S58A12T02 | 73 | 57.65 | 3.233 |
| S58A12T03 | 182 | 1.63 | 0.067 |
| S58A12T04 | 225 | 1.32 | 0.033 |
| S58A12T05 | 166 | 0.00 | 0.000 |
| S58A13T01 | 153 | 0.65 | 0.033 |
| S58A13T02 | 213 | 3.64 | 0.033 |
| S58A13T03 | 159 | 1.25 | 0.067 |
| S58A13T04 | 18 | 87.50 | 3.900 |
| S58A13T05 | 235 | 2.50 | 0.067 |
| S58A14T01 | 125 | 31.49 | 1.700 |
| S58A14T02 | 79 | 57.61 | 3.433 |
| S58A14T03 | 64 | 64.61 | 3.767 |
| S58A14T04 | 106 | 50.47 | 3.467 |
| S58A14T05 | 146 | 13.69 | 0.633 |

Exact repeats mean identical exported coordinates, not confirmed biological stillness. See results/constant_pose_runs.csv for inclusive zero-based frame ranges. No repeats are deleted.

## Evidence and reproducibility

- results/manifest.json: source paths, hashes and parsing errors.
- results/trial_summary.csv: clip-level measurements.
- results/review_events.csv (when flags exist): exact frame pairs for inspection.
- results/com/: per-frame CoM and camera displacements.
- results/segment_mass_model.csv and segment_model.json: full mass and landmark mapping.
- results/landmark_sensitivity.csv: alternative mappings, not uncertainty bounds.
- config.json and code/: frozen configuration and scripts.

## Questions for the team

Confirm XYZ units/order, camera-to-floor orientation, original timestamps, missing/trimmed recordings and body-tracking confidence. Determine whether changing limb scale is in the raw export or preprocessing. Review full event coverage before selecting PINN trials. No ground contact, BoS, joint forces or external perturbations are inferred here.

## Evidence figures

![A10_skeleton_snapshots](results/plots/A10_skeleton_snapshots.png)

![A11_skeleton_snapshots](results/plots/A11_skeleton_snapshots.png)

![A12_skeleton_snapshots](results/plots/A12_skeleton_snapshots.png)

![A13_skeleton_snapshots](results/plots/A13_skeleton_snapshots.png)

![A14_skeleton_snapshots](results/plots/A14_skeleton_snapshots.png)

![real_CoM_comparison](results/plots/real_CoM_comparison.png)

![shared_limb_scaling](results/plots/shared_limb_scaling.png)

![temporal_repeats](results/plots/temporal_repeats.png)

![tracking_diagnostics](results/plots/tracking_diagnostics.png)



## Derived blank-row repairs and trial availability

The supplied archive contains 24 numeric trials out of 25 expected. The derived repair layer replaced 2087 fully blank frames across 57 gaps. Original files were not modified. Short gaps of 1–3 frames use the preceding valid row; longer internal gaps use per-coordinate linear interpolation; boundary gaps use the nearest valid row. Entire missing or empty trials are never synthesized.

See `../../REPAIR_ASSESSMENT.md` for trial-level repair fractions, boundary carries, and missing/empty trials.

<!-- MANUAL_A11_PHASE_UPDATE_START -->
## Manual A11 phase update

- Marked trials: 5.
- Strict phase-order validation: **fail**.
- Manual observation: All A11 trials were marked, but real rows stop immediately before true ground contact. The marked apparent-contact frames are pre-contact proxies, and subsequent rows are repaired rather than observed contact/post-fall motion.
- Camera-axis interpretation: `camera_x`.
- Modeling decision: `exclude_primary_training_and_generalization`.
- Recommendation: Do not use S58 for primary full-trajectory training, contact/post-fall supervision, or headline generalization metrics. It may be retained only for an explicitly labeled exploratory pre-contact or censored-data analysis with repaired frames masked.

See `../../analysis_inputs/FRONTFALL_PHASE_STATUS.md` for trial-level repair overlap and phase frames. The automatic suggestions are superseded by the manual notes.
<!-- MANUAL_A11_PHASE_UPDATE_END -->
